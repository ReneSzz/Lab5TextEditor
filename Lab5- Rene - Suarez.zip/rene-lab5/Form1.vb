﻿' Date: July 30th 2020 
' By: Rene Suarez 
' Program Name: Lab 5 Text Editor 
' Program description: text editor that uses StreamReader and StreamWriter to write and read files from the computer 
' The user can create new files save files and exit 
Option Strict On
Imports System.Diagnostics.Eventing.Reader
Imports System.IO
Imports System.Text

Public Class frmLab5

    Private Sub OpenClick(sender As Object, e As EventArgs) Handles mnuFileOpen.Click, btnNew.Click
        Dim inputStream As StreamReader

        ' Checks to see if the txt has been modified if it has been then the user gets propmpted to save their file
        ' If the user says yes then they are showed a dialog box and they can choose where to save their file to.
        If txtArea.Modified Then
            If MsgBox("Do you want to save?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Dim outputStream As StreamWriter
                If saveDialog.ShowDialog() = DialogResult.OK Then
                    outputStream = New StreamWriter(saveDialog.FileName)
                    outputStream.Write(txtArea.Text)
                    outputStream.Close()

                End If
            End If

        End If

        ' Shows a dialog that asks the user which file they want to open and then puts the contents of the file into the text editor 
        If openDialog.ShowDialog() = DialogResult.OK Then
            inputStream = New StreamReader(openDialog.FileName)
            txtArea.Text = inputStream.ReadToEnd()
            inputStream.Close()




            ' Gets and sets the directory and the file name of the file to variables and then combines them.
            '  Sets the title of the program to " Text Editor " and the filepath of the text file being used. 
            Dim FileName, directory, fullpath As String
            directory = Path.GetDirectoryName(openDialog.FileName)
            FileName = Path.GetFileName(openDialog.FileName)
            fullpath = directory & "\" & FileName



            Me.Text = "Text Editor " & fullpath
        End If




    End Sub

    Private Sub NewClick(sender As Object, e As EventArgs) Handles mnuNew.Click


        ' Checks to see if the txt has been modified if it has been then the user gets propmpted to save their file.
        ' If the user says yes then they are showed a dialog box and they can choose where to save their file. Using stream writer 

        If txtArea.Modified Then
            If MsgBox("Do you want to save?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Dim outputStream As StreamWriter
                If saveDialog.ShowDialog() = DialogResult.OK Then
                    outputStream = New StreamWriter(saveDialog.FileName)
                    outputStream.Write(txtArea.Text)
                    outputStream.Close()





                End If

            End If

        End If
        ' Clears the text box and the title is set back to just Text Editor without a file path. 
        txtArea.Clear()
        Me.Text = "Text Editor"


    End Sub

    Private Sub SaveasClick(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click

        ' Shows a dialog box that asks the user where they want to save their file to then uses StreamWriter to write the file 
        Dim outputStream As StreamWriter
        If saveDialog.ShowDialog() = DialogResult.OK Then
            outputStream = New StreamWriter(saveDialog.FileName)
            outputStream.Write(txtArea.Text)
            outputStream.Close()

        End If
    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        ' Shows message when the about box is clicked. 
        MessageBox.Show("NETD 2202" & vbCrLf & vbCrLf & "Lab 5" & vbCrLf & vbCrLf & "R. Suarez")

    End Sub
    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click
        ' copies highlighted text.
        txtArea.Copy()

    End Sub

    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        ' Cuts highlighted text.
        txtArea.Cut()
    End Sub

    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        ' pastes contents of clip board.
        txtArea.Paste()

    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click


        ' Honestly, I'm not really sure how to do this 
        ' I tried making it do the save prompt if the title was just "Text Editor" because that means 
        ' that a file wouldn't be currently open so you would make a new path. That didn't seem to work lol 
        If Me.Text = "Text Editor" Then

            Dim outputStream As StreamWriter
            If saveDialog.ShowDialog() = DialogResult.OK Then
                outputStream = New StreamWriter(saveDialog.FileName)
                outputStream.Write(txtArea.Text)
                outputStream.Close()




            Else
                ' Tried to just make the file save without the dialog box. 

                outputStream = New StreamWriter(saveDialog.FileName)
                outputStream.Write(txtArea.Text)
                outputStream.Close()


            End If

        End If


    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click


        ' Checks to see if txtArea has been modified and if it has been then the program propts the user
        ' to save if they say yes then it will save their file and then close 
        If txtArea.Modified Then
            If MsgBox("Do you want to save?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Dim outputStream As StreamWriter
                If saveDialog.ShowDialog() = DialogResult.OK Then
                    outputStream = New StreamWriter(saveDialog.FileName)
                    outputStream.Write(txtArea.Text)
                    outputStream.Close()
                    Application.Exit()
                End If

                ' if no application exits 
            Else
                Application.Exit()
            End If


        End If

    End Sub
End Class
